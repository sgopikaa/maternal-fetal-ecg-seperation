"""
DL Model 1 - 1D Convolutional Autoencoder
-------------------------------------------
Learns a direct nonlinear mapping from the multi-channel mixed abdominal
ECG to the fetal ECG waveform. Unlike ICA, it can exploit local temporal
morphology and handle overlapping maternal/fetal QRS complexes.

Architecture: multi-channel 1D-CNN encoder -> bottleneck -> 1D-CNN decoder
producing a single-channel fetal ECG estimate, trained with MSE against
the (synthetic) ground-truth fetal reference.
"""

import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models

SEGMENT_LEN = 512


def build_autoencoder(n_channels, segment_len=SEGMENT_LEN):
    inputs = layers.Input(shape=(segment_len, n_channels))

    x = layers.Conv1D(32, 9, padding="same", activation="relu")(inputs)
    x = layers.MaxPooling1D(2, padding="same")(x)
    x = layers.Conv1D(64, 7, padding="same", activation="relu")(x)
    x = layers.MaxPooling1D(2, padding="same")(x)
    x = layers.Conv1D(128, 5, padding="same", activation="relu")(x)

    x = layers.Conv1D(128, 5, padding="same", activation="relu")(x)
    x = layers.UpSampling1D(2)(x)
    x = layers.Conv1D(64, 7, padding="same", activation="relu")(x)
    x = layers.UpSampling1D(2)(x)
    x = layers.Conv1D(32, 9, padding="same", activation="relu")(x)

    outputs = layers.Conv1D(1, 1, padding="same", activation="linear")(x)

    model = models.Model(inputs, outputs, name="fetal_ecg_cnn_autoencoder")
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-3), loss="mse")
    return model


def _segment_signal(signal, segment_len, hop):
    segs = []
    for start in range(0, len(signal) - segment_len + 1, hop):
        segs.append(signal[start:start + segment_len])
    return segs


def build_training_arrays(dataset, segment_len=SEGMENT_LEN, hop=256):
    """dataset: list of samples from signal_generator.generate_dataset()"""
    X, y = [], []
    for sample in dataset:
        channels = sample["channels"]  # (n_channels, N)
        fetal_ref = sample["fetal_ref"]
        n_channels, N = channels.shape
        if N < segment_len:
            continue
        for start in range(0, N - segment_len + 1, hop):
            seg_channels = channels[:, start:start + segment_len].T  # (T, C)
            seg_fetal = fetal_ref[start:start + segment_len]
            std = seg_channels.std()
            if std < 1e-6:
                continue
            X.append(seg_channels / (std + 1e-8))
            y.append((seg_fetal / (np.std(seg_fetal) + 1e-8))[:, None])
    return np.array(X), np.array(y)


def train_autoencoder(dataset, epochs=15, batch_size=16, verbose=0):
    X, y = build_training_arrays(dataset)
    n_channels = X.shape[-1]
    model = build_autoencoder(n_channels)
    history = model.fit(
        X, y,
        epochs=epochs,
        batch_size=batch_size,
        validation_split=0.15,
        verbose=verbose,
    )
    return model, history


def extract_fetal_ecg(model, channels, segment_len=SEGMENT_LEN):
    """Run the trained autoencoder over a full-length multi-channel signal
    using overlap-add on non-overlapping segments (padded at the end)."""
    n_channels, N = channels.shape
    pad = (-N) % segment_len
    padded = np.pad(channels, ((0, 0), (0, pad)), mode="edge")
    n_segs = padded.shape[1] // segment_len

    out = np.zeros(padded.shape[1])
    for i in range(n_segs):
        seg = padded[:, i * segment_len:(i + 1) * segment_len].T
        std = seg.std() + 1e-8
        seg_norm = (seg / std)[None, ...]
        pred = model.predict(seg_norm, verbose=0)[0, :, 0]
        out[i * segment_len:(i + 1) * segment_len] = pred

    return out[:N]
