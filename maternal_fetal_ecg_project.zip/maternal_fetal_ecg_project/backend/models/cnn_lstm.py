"""
DL Model 2 - CNN-LSTM Sequence Model
----------------------------------------
Models the *temporal evolution* of the fetal heart-rate trend (as opposed
to the Random Forest, which looks at a single window's summary
statistics). 1D convolutions pick up local deceleration/acceleration
shapes; the LSTM tracks how those evolve across the recording to flag
fetal distress patterns (e.g. sustained late decelerations, reduced
variability).
"""

import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models

TREND_LEN = 10  # seconds of 1 Hz fetal-HR-trend history per prediction window


def _fit_to_length(trend, length=TREND_LEN):
    if len(trend) >= length:
        return trend[:length]
    pad = length - len(trend)
    return np.pad(trend, (0, pad), mode="edge")


def build_training_arrays(dataset, length=TREND_LEN):
    X, y = [], []
    for sample in dataset:
        trend = np.asarray(sample["fetal_hr_trend"], dtype=float)
        trend = _fit_to_length(trend, length)
        trend_norm = (trend - 140.0) / 40.0  # rough fixed normalization around typical fHR
        X.append(trend_norm[:, None])
        y.append(1.0 if sample["fetal_distress"] else 0.0)
    return np.array(X), np.array(y)


def build_cnn_lstm(length=TREND_LEN):
    inputs = layers.Input(shape=(length, 1))
    x = layers.Conv1D(16, 3, padding="same", activation="relu")(inputs)
    x = layers.Conv1D(32, 3, padding="same", activation="relu")(x)
    x = layers.LSTM(32, return_sequences=False)(x)
    x = layers.Dense(16, activation="relu")(x)
    outputs = layers.Dense(1, activation="sigmoid")(x)

    model = models.Model(inputs, outputs, name="fetal_distress_cnn_lstm")
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-3),
                  loss="binary_crossentropy", metrics=["accuracy"])
    return model


def train_cnn_lstm(dataset, epochs=25, batch_size=8, verbose=0):
    X, y = build_training_arrays(dataset)
    model = build_cnn_lstm()
    history = model.fit(
        X, y,
        epochs=epochs,
        batch_size=batch_size,
        validation_split=0.15,
        verbose=verbose,
    )
    return model, history


def predict_distress(model, fetal_hr_trend, length=TREND_LEN):
    trend = _fit_to_length(np.asarray(fetal_hr_trend, dtype=float), length)
    trend_norm = (trend - 140.0) / 40.0
    x = trend_norm[None, :, None]
    prob = float(model.predict(x, verbose=0)[0, 0])
    label = "distress_risk" if prob >= 0.5 else "reassuring"
    return label, prob
