"""
ML Model 1 - Independent Component Analysis (FastICA)
-------------------------------------------------------
Classical blind-source-separation approach. The abdominal ECG is modelled
as a linear mixture of independent sources (maternal ECG, fetal ECG,
noise). FastICA un-mixes the channels; the maternal component is
identified as the one most correlated with the strongest-amplitude
channel (mECG dominates in abdominal recordings), and is then subtracted
out, leaving the fetal-dominant component(s).
"""

import numpy as np
from sklearn.decomposition import FastICA


def separate_ica(channels, n_components=None, random_state=0):
    """
    channels: (n_channels, N) preprocessed abdominal ECG
    returns: dict with maternal_component, fetal_component, mixing info
    """
    n_channels = channels.shape[0]
    n_components = n_components or n_channels

    X = channels.T  # (samples, channels) as sklearn expects

    ica = FastICA(n_components=n_components, random_state=random_state, max_iter=1000)
    sources = ica.fit_transform(X).T  # (n_components, N)

    # Identify maternal component: highest correlation with the raw channel
    # average (maternal QRS dominates abdominal recordings in amplitude).
    ref = channels.mean(axis=0)
    correlations = [abs(np.corrcoef(src, ref)[0, 1]) for src in sources]
    maternal_idx = int(np.argmax(correlations))

    # Fetal component: among remaining sources, the one with the most
    # regular high-frequency peak structure (highest kurtosis is a decent,
    # simple proxy for a peaky QRS-like source).
    remaining = [i for i in range(n_components) if i != maternal_idx]
    kurtosis_scores = []
    for i in remaining:
        s = sources[i]
        s = (s - s.mean()) / (s.std() + 1e-8)
        kurtosis_scores.append(np.mean(s ** 4))
    fetal_idx = remaining[int(np.argmax(kurtosis_scores))]

    maternal_component = sources[maternal_idx]
    fetal_component = sources[fetal_idx]

    # normalize sign/scale for consistent downstream processing
    fetal_component = fetal_component / (np.std(fetal_component) + 1e-8)
    maternal_component = maternal_component / (np.std(maternal_component) + 1e-8)

    return {
        "maternal_component": maternal_component,
        "fetal_component": fetal_component,
        "all_sources": sources,
        "maternal_idx": maternal_idx,
        "fetal_idx": fetal_idx,
    }
