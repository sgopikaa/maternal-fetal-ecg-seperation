"""
ML Model 2 - Random Forest Classifier
----------------------------------------
Classifies a window of fetal heart-rate data into a cardiotocography-style
category (normal / bradycardia / tachycardia / low-variability distress)
using handcrafted statistical features (mean/std/range FHR, RMSSD).
"""

import numpy as np
from sklearn.ensemble import RandomForestClassifier

from qrs_detection import extract_features, label_from_features

FEATURE_ORDER = ["mean_fhr", "std_fhr", "min_fhr", "max_fhr", "range_fhr", "rmssd"]


def _feats_to_vector(feats):
    return [feats[k] for k in FEATURE_ORDER]


def build_training_data(dataset):
    X, y = [], []
    for sample in dataset:
        feats = extract_features(sample["fetal_hr_trend"])
        label = label_from_features(feats)
        if label == "undetermined":
            continue
        X.append(_feats_to_vector(feats))
        y.append(label)
    return np.array(X), np.array(y)


def train_rf(dataset, n_estimators=200, random_state=0):
    X, y = build_training_data(dataset)
    clf = RandomForestClassifier(
        n_estimators=n_estimators, random_state=random_state, max_depth=6
    )
    clf.fit(X, y)
    return clf


def predict_condition(clf, feats):
    x = np.array([_feats_to_vector(feats)])
    label = clf.predict(x)[0]
    proba = clf.predict_proba(x)[0]
    classes = clf.classes_
    proba_map = {cls: float(p) for cls, p in zip(classes, proba)}
    return label, proba_map
